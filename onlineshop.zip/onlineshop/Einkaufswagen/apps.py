from django.apps import AppConfig


class EinkaufswagenConfig(AppConfig):
    name = 'Einkaufswagen'

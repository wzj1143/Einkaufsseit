from django.http import  HttpResponseRedirect
from django.shortcuts import render, redirect

import Users
from Einkaufswagen.models import BestellungInfo, BestellungDetails
from Waren.models import WarenInfo
from . import models
from .models import User
from .forms import UserForm,RegisterForm


# Create your views here.
def User_Register(request):
    '''
    if request.session.get('is_login', None):
        # 登录状态不允许注册。你可以修改这条原则！
        return redirect("/index/")
    '''
    # zeigen Waren in Einkaufswagen(benutzen cookie: waren_id,waren_menge)
    waren_gesamt_Menge_in_Einkaufswagen = 0
    all_waren = request.COOKIES.items()
    for waren_id, waren_menge in all_waren:
        # waren_id muss digit sein,
        # wenn jetzt diese waren_menge nicht ein Teil von Waren,pruefen naechste waren_id
        if not waren_id.isdigit():
            continue
        # Holen die Waren in den aktuell durchlaufenen Cookie
        get_waren = WarenInfo.objects.get(id=waren_id)
        get_waren.waren_menge = waren_menge  # menge jeder Ware
        # rechnen gezamt Waren Menge in Einkaufswagen
        waren_gesamt_Menge_in_Einkaufswagen += int(waren_menge)
    if request.method == "POST":
        register_form = RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():  # 获取数据
            username = register_form.cleaned_data['username']
            password = register_form.cleaned_data['password']
            Email = register_form.cleaned_data['Email']
            adress = register_form.cleaned_data['adress']
            same_name_user = models.User.objects.filter(username=username)
            if same_name_user:  # 用户名唯一
                message = '用户已经存在，请重新选择用户名！'
                return render(request, 'User_Register.html', locals())
            same_email_user = models.User.objects.filter(Email=Email)
            if same_email_user:  # 邮箱地址唯一
                message = '该邮箱地址已被注册，请使用别的邮箱！'
                return render(request, 'User_Register.html', locals())

                # 当一切都OK的情况下，创建新用户

            new_user = models.User.objects.create()
            new_user.username = username
            new_user.password = password
            new_user.Email = Email
            new_user.adress = adress
            new_user.save()
            return render(request, 'User_anmelden.html', locals())  # 自动跳转到登录页面
    register_form = RegisterForm()
    return render(request, 'User_Register.html', locals())

'''
def User_Register(request):
    result = {"code": 1000, "msg": ""}
    if request.method == 'GET':
        data = {
            "title": "registerien"
        }
        return render(request, 'User_Register.html', context=data)
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        email = request.POST.get('email', '')
        address = request.POST.get('address', '')
        print(username,password,email,address)
        # Bestimmen usernam,password,email,address sind nicht leer
        if username and password and email and address:
            User.objects.create(username=username,password=password,Email=email,adress=address)
            result = {"code": 1000, "msg":"success"}
        # else, Information ist nicht full
        else:
            result = {"code": 1001, "msg": "wrong"}
    return JsonResponse(result)
'''
def User_anmelden(request):
    login_form = UserForm()
    # zeigen Waren in Einkaufswagen(benutzen cookie: waren_id,waren_menge)
    waren_gesamt_Menge_in_Einkaufswagen = 0
    all_waren = request.COOKIES.items()
    for waren_id, waren_menge in all_waren:
        # waren_id muss digit sein,
        # wenn jetzt diese waren_menge nicht ein Teil von Waren,pruefen naechste waren_id
        if not waren_id.isdigit():
            continue
        # Holen die Waren in den aktuell durchlaufenen Cookie
        get_waren = WarenInfo.objects.get(id=waren_id)
        get_waren.waren_menge = waren_menge  # menge jeder Ware
        # rechnen gezamt Waren Menge in Einkaufswagen
        waren_gesamt_Menge_in_Einkaufswagen += int(waren_menge)

    if request.session.get('is_login',None):
        return redirect('/index')
    if request.method == "POST":
        login_form = UserForm(request.POST)
        #message = "请检查填写的内容！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            try:
                user = models.User.objects.get(username=username)
                if user.password == password:
                    request.session['is_login'] = True
                    request.session['user_name'] = user.username
                    return redirect('/index/')
                else:
                    message = "密码不正确！"
            except:
                message = "用户不存在！"
        return render(request, 'User_anmelden.html', locals())



    return render(request, 'User_anmelden.html', locals())


'''
def User_anmelden(request):
    if request.method == 'POST':
        username = request.POST.get('username', 'None')
        password = request.POST.get('password', 'None')
        print(username, password)
        # Bestimmen username und password nicht leer sind
        if username and password:
            try:
                user = User.objects.filter(username__exact = username, password__exact=password)
                if user:
                    # vergleich erfolgreich, springe nach index
                   # response = HttpResponseRedirect('/angemeldete_homepage/')
                    response = HttpResponseRedirect('/index/')
                    # username in cookie schreiben, ablaufzeit 3600
                    response.set_cookie('username', username,3600)
                    return response
                else:
                    response = HttpResponse("username das not exist or password not match!")
                    return response
            except:
                return render(request, 'User_anmelden.html')
    else:
        return render(request, 'User_anmelden.html')
'''
'''
def User_abmelden(request):
    response = HttpResponseRedirect('/index')
    all_waren = request.COOKIES.items()
    for waren_id, waren_menge in all_waren:
        # waren_id muss digit sein,
        # wenn jetzt diese waren_menge nicht ein Teil von Waren,pruefen naechste waren_id
        if not waren_id.isdigit():
            continue
        # delete Daten von Einkaufswagen(in cookie)
        response.delete_cookie(waren_id)
    response.delete_cookie('username')
    return response
'''
def User_abmelden(request):
    if not request.session.get('is_login', None):
        # 如果本来就未登录，也就没有登出一说
        return redirect("/index/")
    response = HttpResponseRedirect('/index')
    all_waren = request.COOKIES.items()
    for waren_id, waren_menge in all_waren:
        # waren_id muss digit sein,
        # wenn jetzt diese waren_menge nicht ein Teil von Waren,pruefen naechste waren_id
        if not waren_id.isdigit():
            continue
        # delete Daten von Einkaufswagen(in cookie)
        response.delete_cookie(waren_id)
    response.delete_cookie('username')
    request.session.flush()
    return response

def user_Bestellungen(request):

    ware_in_jede_Bestellung=[]
    ware_in_Bestellung_dic={}
    bestellung_obj_list=[]

    user_name = request.session['user_name']
    users_list = User.objects.all()
    for u in users_list:
        if user_name==u.username:
            user_id=u.id

    bestellung_list = BestellungInfo.objects.all()

    #for u in users_list:
    for b in bestellung_list:
        #if u.id == b.Bestellung_User_id:
        if user_id == b.Bestellung_User_id:
            bestellung_obj_list.append(b)

    #bestellung_obj_list = BestellungInfo.objects.filter(Bestellung_User=User.id)



    for b in bestellung_obj_list:
        #ware_in_Bestellung_list = BestellungDetails.objects.filter(Ware_Bestellung_id=b.id)
        bestellung_detail_list = BestellungDetails.objects.all()
        for d in bestellung_detail_list:
            if b.id == d.Ware_Bestellung.id:
                ware_in_jede_Bestellung.append(d)
        ware_in_Bestellung_dic[b.Bestellung_Nummer]=ware_in_jede_Bestellung
        ware_in_jede_Bestellung=[]





    return render(request, 'user_Bestellungen.html', {"bestellung_obj_list":bestellung_obj_list,
                                                      "ware_in_Bestellung_dic":ware_in_Bestellung_dic,
                                                      "ware_in_jede_Bestellung":ware_in_jede_Bestellung})

from django.db import models
# Create your models here.

class User(models.Model):
    #id=models.CharField(max_length=32,primary_key=True)
    username = models.CharField(max_length=32, unique=True)
    password = models.CharField(max_length=255)
    adress = models.CharField(max_length=200)
    Email = models.CharField(max_length=200)
    # 外键
    #user_Bestellung = models.ForeignKey("Einkaufswagen.BestellungInfo",on_delete=models.SET_NULL,null=True, blank=True)



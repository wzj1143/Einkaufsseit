from django.apps import AppConfig


class WarenConfig(AppConfig):
    name = 'Waren'
